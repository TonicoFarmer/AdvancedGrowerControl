# Advanced Grower Control — Plataforma Agronômica

Plataforma web para gestão agronômica de cultivo: acompanhamento de lavoura (indoor e outdoor), diagnóstico de deficiências nutricionais, manejo integrado de pragas (MIP), agricultura natural (KNF/JADAM), análise de solo com cálculo de remineralização, bioinsumos, calendário, meteorologia e assistente de IA agronômico.

> **Aviso:** os conteúdos de referência (catálogos de deficiências, pragas, bioinsumos e receitas) são educativos. Sempre valide dosagens e práticas com um(a) agrônomo(a) responsável e com a legislação local.

---

## ✨ Funcionalidades

- **Início** — dashboard com clima ao vivo, agenda do dia e acesso rápido aos módulos.
- **Agricultura**
  - **Deficiências Nutricionais** — catálogo com diagnóstico visual, sintomas e correção.
  - **Pragas & MIP** — identificação e controle integrado de pragas.
  - **Análise de Solo** — relações catiônicas (Ca:Mg:K), saturação de bases (V%), metas editáveis e cálculo de remineralização em gramas por volume de substrato.
  - **KNF / JADAM** — receitas e métodos de agricultura natural (JMS, JWA, JHS, EM, etc.).
  - **Bioinsumos** — biblioteca de insumos biológicos.
  - **Cultivo** — Madres, Cultivo Outdoor (Área Externa / Casa de Vegetação), Cultivo Indoor (Setor Vegetativo / Floração) e Pasta de Ciclos.
- **Calendário** — manutenções e registro de MIP.
- **Meteorologia** — dados INMET e diagnóstico climático com IA.
- **Ferramentas** — calculadora de substrato/receita de solo e biblioteca de documentos/PDFs (Drive).
- **IA Agronômica** — assistente baseado em **Gemini** (motores 3.5 e 3.8) para diagnóstico, dosagens e MIP.
- **Multi-idioma** — Português, Inglês, Espanhol e Alemão.
- **Perfis de acesso** — Administrador, Operador e Leitor, com sistema de **publicação** de conteúdo pelo administrador.

---

## 🛠️ Stack

| Camada | Tecnologia |
|---|---|
| Frontend | React 19 + TypeScript + Vite 6 + Tailwind CSS 4 |
| Backend | Express 4 (servidor único, serve a SPA e a API) |
| Banco | PostgreSQL 16 (via `pg`); demo local com PGlite (WASM) |
| IA | `@google/genai` (Gemini API) |
| Mapas | Leaflet |
| i18n | Dicionários próprios (`src/i18n`) |

---

## ✅ Requisitos

- **Node.js 20+** e **npm** (ou `bun`, já que há `bun.lock`).
- **PostgreSQL 16** (produção) — ou usar o `compose.yaml` para subir o banco.
- Uma chave de API do **Gemini** (para o assistente de IA).

---

## 🚀 Como rodar em desenvolvimento

```bash
# 1. Instale as dependências
npm install

# 2. Configure as variáveis de ambiente
cp .env.example .env
# edite o .env com sua GEMINI_API_KEY e as credenciais do banco

# 3. Suba o servidor (Express + Vite em modo dev)
npm run dev
```

A aplicação fica disponível em `http://localhost:3000` (ou na porta definida em `PORT`).

### Banco de dados

A forma mais simples é usar o PostgreSQL do `compose.yaml`:

```bash
docker compose up -d db
```

Ou aponte para um PostgreSQL existente definindo `DATABASE_URL`:

```bash
DATABASE_URL=postgres://usuario:senha@localhost:5432/astraya_agronomica
```

### Primeiro administrador

Na primeira subida, defina as variáveis `ADMIN_NAME`, `ADMIN_EMAIL` e `ADMIN_PASSWORD` no `.env` para criar o usuário administrador automaticamente.

---

## 🏗️ Build de produção

```bash
npm run build   # gera dist/ (client) + dist/server.cjs (servidor empacotado)
npm start       # executa node dist/server.cjs
```

---

## 🔐 Variáveis de ambiente

| Variável | Obrigatória | Descrição |
|---|---|---|
| `GEMINI_API_KEY` | Para a IA | Chave da API do Gemini. |
| `DATABASE_URL` | Para persistir | String de conexão PostgreSQL (`postgres://...`). |
| `PORT` | Não | Porta do servidor (padrão `3000`). |
| `ADMIN_NAME` / `ADMIN_EMAIL` / `ADMIN_PASSWORD` | Não | Cria o primeiro administrador na inicialização. |
| `COOKIE_SECURE` | Não | `true` em produção (HTTPS); `false` em dev HTTP. |
| `APP_URL` | Não | URL pública usada na validação de origem (CSRF). |

> Em produção, use `COOKIE_SECURE=true` e **nunca** versione o `.env` (ele já está no `.gitignore`).

---

## 📁 Estrutura

```
├── server.ts               # Express + API + autenticação (servidor único)
├── src/
│   ├── App.tsx             # composição da aplicação e navegação
│   ├── components/         # seções e componentes de UI
│   ├── i18n/               # traduções (pt/en/es/de) + dicionário V2
│   ├── data/               # catálogos (deficiências, pragas, bioinsumos, etc.)
│   ├── utils/              # sincronização (localStorage → IndexedDB → API)
│   └── types.ts            # tipos de domínio
├── public/images/          # imagens estáticas (logo, deficiências, pragas)
├── docs/                   # documentação complementar
├── compose.yaml            # PostgreSQL via Docker
├── Dockerfile              # build da aplicação
└── .env.example            # modelo de variáveis
```

---

## 👥 Perfis e permissões

| Ação | Administrador | Operador | Leitor |
|---|---|---|---|
| Ver conteúdo | ✅ | ✅ | ✅ |
| Criar/editar próprio conteúdo | ✅ | ✅ (com toggle de edição) | ❌ |
| Publicar conteúdo para todos | ✅ | ❌ | ❌ |
| Gerenciar usuários | ✅ | ❌ | ❌ |

O **Operador** possui um botão no cabeçalho (nome + "OPERADOR") que **liga/desliga** a edição de blocos nas seções de Cultivo.

---

## 🤖 IA Agronômica (Gemini)

- Endpoint protegido por sessão: `POST /api/ai/diagnose`.
- Motores suportados: **Gemini 3.5** (`gemini-3.5-flash`) e **Gemini 3.8** (`gemini-3.8-flash`), com fallback automático.
- Para habilitar, defina `GEMINI_API_KEY` no ambiente.

---

## 🧩 Persistência

O cliente usa uma sincronização em camadas:

1. **localStorage** (cache imediato);
2. **IndexedDB** (fila offline, coleções grandes);
3. **API** `PUT /api/data/:key` — persistência definitiva em PostgreSQL (JSONB).

---

## 📚 Documentação

- [`docs/ARQUITETURA.md`](docs/ARQUITETURA.md) — arquitetura e decisões técnicas.
- [`docs/SECOES.md`](docs/SECOES.md) — descrição das seções.
- [`docs/GUIA-EVOLUCAO.md`](docs/GUIA-EVOLUCAO.md) — guia para evoluir o projeto.
- [`RUNBOOK-IMPLANTACAO.md`](RUNBOOK-IMPLANTACAO.md) — passo a passo de implantação em produção.
- [`README-Docker.md`](README-Docker.md) — instruções do Docker.

---

## 📜 Scripts

| Comando | Descrição |
|---|---|
| `npm run dev` | Sobe o servidor em modo desenvolvimento (`tsx server.ts`). |
| `npm run build` | Build do client (Vite) + bundle do servidor (esbuild). |
| `npm start` | Executa o build de produção (`node dist/server.cjs`). |
| `npm run lint` | Checagem de tipos (`tsc --noEmit`). |

---

## ⚖️ Licença

Proprietário — código fechado. Consulte o responsável pelo projeto antes de distribuir.
